import xbmcaddon

MainBase = 'https://bit.ly/3hzGZjV'
addon = xbmcaddon.Addon('plugin.video.anwindy')